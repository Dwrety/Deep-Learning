import os 
import numpy as np 
import argparse as ap 
import time 
import datetime


# class Dir:
#     def __init__(self, name):
#         self.name = name

#         if not os.path.exist(name):
#             os.mkdir(name)

#     def __str__(self):
#         return self.name

# LOG_DIR = Dir("Logs")
# MODEL_DIR = Dir("Models")


timestamp = datetime.datetime.now().strftime('%m%d-%H:%M:%S')
arg_parser = ap.ArgumentParser()
arg_parser.add_argument("-mode", "--mode", default="train")
arg_parser.add_argument("-model", "--model", default=None)
arg_parser.add_argument("-b", action="store_true", default=False)
arg_parser.add_argument("-l", action="store_true", default=False)
args = arg_parser.parse_args()
# print(args)


TRAIN_OR_TEST = args.mode == "train" # 1: train, 0: test
MODEL_PARAMS = args.model

BEST_MODEL = args.b
CKPT = args.l

add_channel_dim = True 
FRAME_SIZE = 40
BLANK_IDX = 46
NUM_PHONEME = 46
PHONEME_EMBED_SIZE = 256
SOS_IDX = NUM_PHONEME  # 46
NUM_CLASSES = NUM_PHONEME + 1 # 47 = 46 phonemes + blank
EOS_IDX = NUM_PHONEME + 1 # 47
PADDING_IDX = NUM_PHONEME + 2 # 48
VOCAB_SIZE = NUM_PHONEME + 3 # 49
LEARNING_RATE = 1e-4
LOG_FILE = 'log/log'
LM_LERANING_RATE = 1e-5
BATCH_SIZE = 64
RNN_CELL = "lstm"
NUM_LAYERS = 3
NUM_RNN_UNITS = 256
USE_BRNN = True # pytorch supports bidirectional lstm and gru, which is great.
BEAM_SIZE = 10
DROPOUT_PROB = 0.2
WEIGHT_DACAY = 5e-4  # 5e-3
OPTIMIZER = "sgd"
MOMENTUM = 0.9
NUM_FEATURES = 512 
NUM_EPOCHS = 200

LR_SCHEDULER_DACAY = 0.8
WEIGHT_DROP = True
WEIGHT_DROP_PROB = 0.2


def log(*args):
    LOG_FILE = open(f'{LOG_DIR}/{args.mode}.{timestamp}.log', 'w')
    print(*args)
    print(*args, file=LOG_FILE, flush=True)











