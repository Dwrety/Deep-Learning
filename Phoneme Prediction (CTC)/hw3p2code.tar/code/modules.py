import configs
import tensorflow as tf
from tensorflow.keras import backend as K
import tensorflow.keras.layers as Layers
from phoneme_list import *
import numpy as np


def model(model_type='cnn_blstm', 
    units=configs.NUM_RNN_UNITS, 
    input_dim=configs.FRAME_SIZE,
    output_dim=configs.NUM_CLASSES,
    dropout=configs.DROPOUT_PROB,
    cudnn=False,
    n_layers=configs.NUM_LAYERS):
    
    if model_type == 'brnn':
        network_model = brnn(units, input_dim, output_dim, dropout)
    elif model_type == 'deep_rnn':
        network_model = deep_rnn(units, input_dim, output_dim, dropout, n_layers)
    elif model_type == 'blstm':
        network_model = blstm(units, input_dim, output_dim, dropout, cudnn=cudnn, n_layers=n_layers)
    elif model_type == 'deep_lstm':
        network_model = deep_lstm(units, input_dim, output_dim, dropout, cudnn=cudnn, n_layers=n_layers)
    elif model_type == 'cnn_blstm':
        network_model = cnn_blstm(units, input_dim, output_dim, dropout, cudnn=cudnn, n_layers=n_layers)
    else:
        raise ValueError("Cannot find this model: ", model_type)
    return network_model


def brnn(units, input_dim=40, output_dim=47, dropout=0.2, numb_of_dense=3, n_layers=1):
    """
    Baidu Deep Speech architecture: Scaling up end-to-end speech recognition (https://arxiv.org/pdf/1412.5567.pdf)
    :param units: Hidden units per layer
    :param input_dim: Size of input dimension (number of features), default=26
    :param output_dim: Output dim of final layer of model (input to CTC layer), default=29
    :param dropout: Dropout rate, default=0.2
    :param numb_of_dense: Number of fully connected layers before recurrent, default=3
    :param n_layers: Number of bidirectional recurrent layers, default=1
    :return: network_model: brnn
    Default model contains:
     1 layer of masking
     3 layers of fully connected clipped ReLu (DNN) with dropout 20 % between each layer
     1 layer of BRNN
     1 layers of fully connected clipped ReLu (DNN) with dropout 20 % between each layer
     1 layer of softmax
    """
    dtype = 'float32'
    kernel_init_dense = 'random_normal'
    bias_init_dense = 'random_normal'
    class_init = tf.keras.initializers.Constant(np.load("log_priors.npy"), dtype=dtype, verify_shape=True)
    kernel_init_rnn = 'glorot_uniform'
    bias_init_rnn = 'zeros'

    # network_model
    # Input Layer, dim [batch_size x timesteps, x frame_size]
    input_data = Layers.Input(name='input_layer', shape=(None, input_dim), dtype=dtype)

    # Masking layer
    x = Layers.Masking(mask_value=0., name='mask_layer')(input_data)

    # stacks of fc layers with dropout 0.2
    for i in range(numb_of_dense):
        x = Layers.TimeDistributed(Layers.Dense(units=units//2, kernel_initializer=kernel_init_dense,
                                                bias_initializer=bias_init_dense, activation='selu',
                                                name='fc_'+str(i+1)))(x)
        x = Layers.TimeDistributed(Layers.Dropout(dropout), name='dropout_'+str(i+1))(x)

    # One layer of Bi-directional RNN, ReLU act
    for i in range(n_layers):
        x = Layers.Bidirectional(Layers.SimpleRNN(units//2, activation='relu', kernel_initializer=kernel_init_rnn, dropout=0.2,
                                    bias_initializer=bias_init_rnn, return_sequences=True),
                          merge_mode='concat', name='bi_rnn'+str(i+1))(x)

    # One fc layer with dropout 0.2
    x = Layers.TimeDistributed(Layers.Dense(units=units, kernel_initializer=kernel_init_dense, bias_initializer=bias_init_dense,
                              activation='selu'), name='fc_4')(x)
    x = Layers.TimeDistributed(Layers.Dropout(dropout), name='dropout_4')(x)

    # classifier layer, softmax 
    y_pred = Layers.TimeDistributed(Layers.Dense(units=output_dim, kernel_initializer=kernel_init_dense,
                                   bias_initializer=class_init, activation='softmax'), name='classifier')(x)

    # ctc decode 
    # ground truth labels [batch_size x time_steps]
    labels = Layers.Input(name='labels', shape=[None], dtype=dtype)
    input_length = Layers.Input(name='input_length', shape=[1], dtype=dtype)
    label_length = Layers.Input(name='label_length', shape=[1], dtype=dtype)

    loss = Layers.Lambda(function=ctc_lambda_func, name='ctc', output_shape=(1,))(
                      [y_pred, labels, input_length, label_length])

    network_model = tf.keras.Model(inputs=[input_data, labels, input_length, label_length], outputs=loss)
    return network_model


def deep_rnn(units, input_dim=40, output_dim=47, dropout=0.2, numb_of_dense=3, n_layers=3):
    """
    :param units: Hidden units per layer
    :param input_dim: Size of input dimension (number of features), default=26
    :param output_dim: Output dim of final layer of model (input to CTC layer), default=29
    :param dropout: Dropout rate, default=0.2
    :param numb_of_dense: Number of fully connected layers before recurrent, default=3
    :param n_layers: Number of simple RNN layers, default=3
    :return: network_model: deep_rnn
    Default model contains:
     1 layer of masking
     3 layers of fully connected clipped ReLu (DNN) with dropout 20 % between each layer
     3 layers of RNN with 20% dropout
     1 layers of fully connected clipped ReLu (DNN) with dropout 20 % between each layer
     1 layer of softmax
    """

    # Input data type
    dtype = 'float32'

    # Kernel and bias initializers for fully connected dense layers
    kernel_init_dense = 'random_normal'
    bias_init_dense = 'random_normal'

    # Kernel and bias initializers for recurrent layer
    kernel_init_rnn = 'glorot_uniform'
    bias_init_rnn = 'zeros'

    # network_model
    # Input Layer, dim [batch_size x timesteps, x frame_size]
    input_data = Layers.Input(name='input_layer', shape=(None, input_dim), dtype=dtype)

    # Masking layer
    x = Layers.Masking(mask_value=0., name='mask_layer')(input_data)

    # stacks of fc layers with dropout 0.2
    for i in range(numb_of_dense):
        x = Layers.TimeDistributed(Layers.Dense(units=units//2, kernel_initializer=kernel_init_dense,
                                                bias_initializer=bias_init_dense, activation=clipped_relu,
                                                name='fc_'+str(i+1)))(x)
        x = Layers.TimeDistributed(Layers.Dropout(dropout), name='dropout_'+str(i+1))(x)                                                
    
    # Deep RNN network with 3 layers uni-direction
    for i in range(0, n_layers):
        x = Layers.SimpleRNN(units, activation='relu', kernel_initializer=kernel_init_rnn, bias_initializer=bias_init_rnn,
                      dropout=dropout, return_sequences=True, name=('deep_rnn_'+ str(i+1)))(x)

    # One fc layer with dropout 0.2
    x = Layers.TimeDistributed(Layers.Dense(units=units, kernel_initializer=kernel_init_dense, bias_initializer=bias_init_dense,
                              activation='relu'), name='fc_4')(x)
    x = Layers.TimeDistributed(Layers.Dropout(dropout), name='dropout_4')(x)

    # classifier layer, softmax 
    y_pred = Layers.TimeDistributed(Layers.Dense(units=output_dim, kernel_initializer=kernel_init_dense,
                                   bias_initializer=bias_init_dense, activation='softmax'), name='classifier')(x)
    # ctc decode 
    # ground truth labels [batch_size x time_steps]
    labels = Layers.Input(name='labels', shape=[None], dtype=dtype)
    input_length = Layers.Input(name='input_length', shape=[1], dtype=dtype)
    label_length = Layers.Input(name='label_length', shape=[1], dtype=dtype)

    loss = Layers.Lambda(function=ctc_lambda_func, name='ctc', output_shape=(1,))(
                      [y_pred, labels, input_length, label_length])

    network_model = tf.keras.Model(inputs=[input_data, labels, input_length, label_length], outputs=loss)
    return network_model


def blstm(units, input_dim=40, output_dim=47, dropout=0.2, numb_of_dense=3, cudnn=False, n_layers=1):
    """
     1 layer of masking
     3 layers of fully connected clipped ReLu (DNN) with dropout 20 % between each layer
     1 layer of BLSTM
     1 layers of fully connected clipped ReLu (DNN) with dropout 20 % between each layer
     1 layer of softmax

    """ 
    # Input data type
    dtype = 'float32'
    kernel_init_dense = 'random_normal'
    bias_init_dense = 'random_normal'
    kernel_init_rnn = 'glorot_uniform'
    bias_init_rnn = 'random_normal'

    input_data = Layers.Input(name='input_layer', shape=(None, input_dim), dtype=dtype)
    x = Layers.Masking(mask_value=0., name='mask_layer')(input_data)

    if cudnn:
        # masking not supported 
        x = input_data
    else:
        # Masking layer
        x = Masking(mask_value=0., name='mask_layer')(input_data)

    for i in range(numb_of_dense):
        x = Layers.TimeDistributed(Layers.Dense(units=units//2, kernel_initializer=kernel_init_dense,
                                                bias_initializer=bias_init_dense, activation=clipped_relu,
                                                name='fc_'+str(i+1)))(x)    
        x = Layers.TimeDistributed(Layers.Dropout(dropout), name='dropout_'+str(i+1))(x)

    if cudnn:
        for i in range(n_layers):
            x = Layers.Bidirectional(Layers.CuDNNLSTM(units//2, kernel_initializer=kernel_init_rnn, bias_initializer=bias_init_rnn,
                                        unit_forget_bias=True, return_sequences=True),
                              merge_mode='sum', name=('CuDNN_bi_lstm' + str(i+1)))(x)
    else:
        for i in range(n_layers):
            x = Layers.Bidirectional(Layers.LSTM(units//2, kernel_initializer=kernel_init_rnn, bias_initializer=bias_init_rnn,
                                        unit_forget_bias=True, return_sequences=True),
                              merge_mode='sum', name=('CuDNN_bi_lstm' + str(i+1)))(x)

    # One fc layer with dropout 0.2
    x = Layers.TimeDistributed(Layers.Dense(units=units, kernel_initializer=kernel_init_dense, bias_initializer=bias_init_dense,
                              activation='relu'), name='fc_4')(x)
    x = Layers.TimeDistributed(Layers.Dropout(dropout), name='dropout_4')(x)

    # classifier layer, softmax 
    y_pred = Layers.TimeDistributed(Layers.Dense(units=output_dim, kernel_initializer=kernel_init_dense,
                                   bias_initializer=bias_init_dense, activation='softmax'), name='classifier')(x)
    # ctc decode 
    # ground truth labels [batch_size x time_steps]
    labels = Layers.Input(name='labels', shape=[None], dtype=dtype)
    input_length = Layers.Input(name='input_length', shape=[1], dtype=dtype)
    label_length = Layers.Input(name='label_length', shape=[1], dtype=dtype)

    loss = Layers.Lambda(function=ctc_lambda_func, name='ctc', output_shape=(1,))(
                      [y_pred, labels, input_length, label_length])

    network_model = tf.keras.Model(inputs=[input_data, labels, input_length, label_length], outputs=loss)
    return network_model

def deep_lstm(units, input_dim=40, output_dim=47, dropout=0.2, numb_of_dense=3, cudnn=False, n_layers=3):
    """
    # modified accordingly to the baseline provided on piazza (no dropout any more, no fc layers anymore)
     1 layer of masking
     3 layers of fully connected clipped ReLu (DNN) with dropout 20 % between each layer
     1 layer of BLSTM
     1 layers of fully connected clipped ReLu (DNN) with dropout 20 % between each layer
     1 layer of softmax

    """ 
    # Input data type
    dtype = 'float32'
    kernel_init_dense = 'random_normal'
    bias_init_dense = 'random_normal'
    kernel_init_rnn = 'glorot_uniform'
    bias_init_rnn = 'random_normal'

    input_data = Layers.Input(name='input_layer', shape=(None, input_dim), dtype=dtype)
    x = Layers.Masking(mask_value=0., name='mask_layer')(input_data)
    if cudnn:
        # masking not supported 
        x = input_data
    else:
        # Masking layer
        x = Layers.Masking(mask_value=0., name='mask_layer')(input_data)

    # for i in range(numb_of_dense):
    #     x = Layers.TimeDistributed(Layers.Dense(units=units//2, kernel_initializer=kernel_init_dense,
    #                                             bias_initializer=bias_init_dense, activation=clipped_relu,
    #                                             name='fc_'+str(i+1)))(x)    
    #     x = Layers.TimeDistributed(Layers.Dropout(dropout), name='dropout_'+str(i+1))(x)

    if cudnn:
        for i in range(n_layers):
            x = Layers.Bidirectional(Layers.CuDNNLSTM(units, kernel_initializer=kernel_init_rnn, bias_initializer=bias_init_rnn,
                                        unit_forget_bias=True, return_sequences=True),
                              merge_mode='concat', name=('CuDNN_bi_lstm' + str(i+1)))(x)
    else:
        for i in range(n_layers):
            x = Layers.Bidirectional(Layers.LSTM(units, kernel_initializer=kernel_init_rnn, bias_initializer=bias_init_rnn,
                                        unit_forget_bias=True, return_sequences=True),
                              merge_mode='concat', name=('CuDNN_bi_lstm' + str(i+1)))(x)
                              
    # One fc layer with dropout 0.2
    # x = Layers.TimeDistributed(Layers.Dense(units=units, kernel_initializer=kernel_init_dense, bias_initializer=bias_init_dense,
    #                           activation='relu'), name='fc_4')(x)
    # x = Layers.TimeDistributed(Layers.Dropout(dropout), name='dropout_4')(x)

    # classifier layer, softmax 
    y_pred = Layers.TimeDistributed(Layers.Dense(units=output_dim, kernel_initializer=kernel_init_dense,
                                   bias_initializer=bias_init_dense, activation='softmax'), name='classifier')(x)
    # ctc decode 
    # ground truth labels [batch_size x time_steps]
    labels = Layers.Input(name='labels', shape=[None], dtype=dtype)
    input_length = Layers.Input(name='input_length', shape=[1], dtype=dtype)
    label_length = Layers.Input(name='label_length', shape=[1], dtype=dtype)

    loss = Layers.Lambda(function=ctc_lambda_func, name='ctc', output_shape=(1,))(
                      [y_pred, labels, input_length, label_length])

    network_model = tf.keras.Model(inputs=[input_data, labels, input_length, label_length], outputs=loss)
    return network_model


def cnn_blstm(units, input_dim=40, output_dim=47, dropout=0.2, cudnn=False, n_layers=3):
    """
     2 layers of CNN Conv1D
     3 layers of BLSTM
     1 layers of fully connected clipped ReLu (DNN) with dropout 20 % between each layer
     1 layer of softmax
    """

    dtype = 'float32'
    kernel_init_dense = 'random_normal'
    bias_init_dense = 'random_normal'
    kernel_init_conv = 'glorot_uniform'
    class_init = tf.keras.initializers.Constant(np.load("log_priors.npy"), dtype=dtype, verify_shape=True)
    bias_init_conv = 'random_normal'
    kernel_init_rnn = 'glorot_uniform'
    bias_init_rnn = 'random_normal'

    input_data = Layers.Input(name='input_layer', shape=(None, input_dim), dtype=dtype)
    # x = Layers.ZeroPadding1D(padding=(0, seq_padding))(input_data)
    # [batch_size, max_time_step, 40]
    x = Layers.Conv1D(filters=units//4, kernel_size=3, strides=2, activation='elu',
               kernel_initializer=kernel_init_conv, bias_initializer=bias_init_conv, name='conv_1')(input_data)
    # x = Layers.TimeDistributed(Layers.Dropout(dropout), name='dropout_1')(x)
    # x = Layers.TimeDistributed(Layers.BatchNormalization(), name='bn1')(x)
    # [batch_size, , units]
    x = Layers.Conv1D(filters=units//2, kernel_size=3, strides=2, activation='elu',
                kernel_initializer=kernel_init_conv, bias_initializer=bias_init_conv, name='conv_2')(x)

    x = Layers.Conv1D(filters=units, kernel_size=1, strides=1, activation='elu', padding='same',
                kernel_initializer=kernel_init_conv, bias_initializer=bias_init_conv, name='conv_3')(x)            

    # x = Layers.Conv1D(filters=units//2, kernel_size=3, strides=1, padding='same', activation='elu',
    #             kernel_initializer=kernel_init_conv, bias_initializer=bias_init_conv, name='conv_3')(x)          

    if cudnn:
        for i in range(n_layers):
            x = Layers.Bidirectional(Layers.CuDNNLSTM(units, kernel_initializer=kernel_init_rnn, bias_initializer=bias_init_rnn,
                                        unit_forget_bias=True, return_sequences=True),
                              merge_mode='concat', name=('CuDNN_bi_lstm' + str(i+1)))(x)
    else:
        for i in range(n_layers):
            x = Layers.Bidirectional(Layers.LSTM(units, kernel_initializer=kernel_init_rnn, bias_initializer=bias_init_rnn,
                                        unit_forget_bias=True, return_sequences=True, activation='tanh', recurrent_dropout=0.2),
                              merge_mode='concat', name=('bi_lstm' + str(i+1)))(x)
                              
    # One fc layer with dropout 0.2
    # x = Layers.TimeDistributed(Layers.Dense(units=units*2, kernel_initializer=kernel_init_dense, bias_initializer=bias_init_dense,
    #                           activation='selu'), name='fc_4')(x)
    # x = Layers.TimeDistributed(Layers.Dropout(dropout), name='dropout_4')(x)

    # classifier layer, softmax 
    y_pred = Layers.TimeDistributed(Layers.Dense(units=output_dim, kernel_initializer=kernel_init_dense,
                                   bias_initializer=class_init, activation='softmax'), name='classifier')(x)
    # ctc decode 
    # ground truth labels [batch_size x time_steps]
    labels = Layers.Input(name='labels', shape=[None], dtype=dtype)
    input_length = Layers.Input(name='input_length', shape=[1], dtype=dtype)
    label_length = Layers.Input(name='label_length', shape=[1], dtype=dtype)

    loss = Layers.Lambda(function=ctc_lambda_func, name='ctc', output_shape=(1,))(
                      [y_pred, labels, input_length, label_length])

    network_model = tf.keras.Model(inputs=[input_data, labels, input_length, label_length], outputs=loss)
    return network_model


def ctc_lambda_func(args, **kwargs):
    print(args)
    y_pred, labels, input_length, label_length = args
    return K.ctc_batch_cost(labels, y_pred, input_length, label_length)

def clipped_relu(x):
    return K.relu(x, max_value=20)

# def log_init(shape, dtype=None):
#     log_priors = np.load('log_priors.npy')
#     return log_priors
