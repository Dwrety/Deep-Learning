import configs
import os
import tensorflow as tf 
from tensorflow.keras import backend as K
import tensorflow.keras.layers as Layers
import time
import tensorflow.keras.utils as utils
import datetime
import pandas as pd
import Levenshtein
import phoneme_list
import modules
import numpy as np 


class DataGenerator(utils.Sequence):
    def __init__(self, 
                list_Inputs,
                list_Labels, 
                batch_size=configs.BATCH_SIZE,
                train=True,
                shuffle=True,
                stride=1):
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.list_Labels = list_Labels
        self.list_Inputs = list_Inputs
        self.train = train
        self.stride = stride
        self.on_epoch_end()

    def on_epoch_end(self):
        self.indexes = np.arange(len(self.list_Inputs))
        if self.shuffle and self.train:
            np.random.shuffle(self.indexes)

    def __data_generation(self, list_IDs_temp):
        Input_temp, Label_temp = list_IDs_temp
        max_time_step_x = max(Input_temp, key=len).shape[0]
        max_time_step_y = max(Label_temp, key=len).shape[0]
        # print(max_time_step_x, max_time_step_y)
        # Input_temp = sorted(Input_temp, key=len, reverse=True)
        # [batch_size x time_step(descend) x frame_size]
        # Label_temp = sorted(Label_temp, key=len, reverse=True)
        # [batch_size x time_step(descend)]
        x = np.zeros((self.batch_size, max_time_step_x, configs.FRAME_SIZE))
        y = np.full((self.batch_size, max_time_step_y), -1)
        input_length = []
        label_length = []
        # pad the data and labels
        for i in range(self.batch_size):
            if i < len(Input_temp):
                x[i,:len(Input_temp[i]),:] = Input_temp[i]
                y[i,:len(Label_temp[i])] = Label_temp[i]
                input_length.append(len(Input_temp[i]))
                label_length.append(len(Label_temp[i]))
            else:
                x[i] = x[len(Input_temp)-1]
                y[i] = y[len(Label_temp)-1]
                input_length.append(input_length[-1])
                label_length.append(label_length[-1])
        input_length = np.array(input_length)
        if self.stride > 1:
            input_length = ((input_length-3)//self.stride + 1).astype(int)
            input_length = ((input_length-3)//self.stride + 1).astype(int)
        return x, y, input_length, np.array(label_length)

    def __test_generation(self, list_IDs_temp):
        Input_temp = list_IDs_temp
        max_time_step_x = max(Input_temp, key=len).shape[0]
        x = np.zeros((self.batch_size, max_time_step_x, configs.FRAME_SIZE))
        y = np.full((self.batch_size, max_time_step_x), -1)
        input_length = []
        for i in range(self.batch_size):
            if i < len(Input_temp):
                x[i, :len(Input_temp[i]), :] = Input_temp[i]
                input_length.append(len(Input_temp[i]))
            else:
                x[i] = x[len(Input_temp)-1]
                input_length.append(input_length[-1])
        input_length = np.array(input_length)
        # label_length = np.array(label_length)
        if self.stride > 1:        
            input_length = ((input_length-5)//self.stride + 1).astype(int)
            input_length = ((input_length-3)//self.stride + 1).astype(int)          
        return x, y, np.array(input_length), np.array(input_length)

    def __len__(self):
        return int(np.ceil(len(self.list_Inputs) / self.batch_size))

    def __getitem__(self, idx):
        idxs = self.indexes[idx*self.batch_size:(idx+1)*self.batch_size]
        if self.train:
            list_IDs_temp = ([self.list_Inputs[k] for k in idxs], [self.list_Labels[k] for k in idxs])
            x_data, y_data, input_length, label_length = self.__data_generation(list_IDs_temp)
            inputs = {'input_layer': x_data, 'labels': y_data, 'input_length':input_length, 'label_length':label_length}

            outputs = {'ctc': np.zeros([self.batch_size])}
            return inputs, outputs
        else:
            list_IDs_temp = [self.list_Inputs[k] for k in idxs]
            x_data, y_data, input_length, label_length = self.__test_generation(list_IDs_temp)
            outputs = {'ctc': np.zeros([self.batch_size])}
            inputs = {'input_layer': x_data, 'labels': y_data, 'input_length':input_length, 'label_length': label_length}
            return inputs, outputs


class LossCallback(tf.keras.callbacks.Callback):
    def __init__(self, test_func, validation_gen, test_gen, model, checkpoint, path_to_save, log_file_path, submission_path):
        self.test_func = test_func
        num_examples = 24724
        self.num_batches = np.ceil(num_examples/configs.BATCH_SIZE)
        self.validation_gen = validation_gen
        self.test_gen = test_gen
        self.model = model 
        self.checkpoint = checkpoint
        self.path_to_save = path_to_save
        self.submission_path = submission_path
        self.log_file_path = log_file_path
        self.values = []
        self.timestamp = datetime.datetime.now().strftime('%m-%d_%H%M') + ".csv"

    def on_batch_end(self, batch, logs={}):
        print("Batch: [{}/{}], Loss: {}".format(batch+1, int(self.num_batches), logs.get('loss')))
        # input_data, _ = self.test_gen.__getitem__(0)
        # x_data = input_data.get('input_layer')
        # input_length = input_data.get('input_length')
        # decoded = beam_decode(self.test_func, x_data, input_length)
        # print(decoded.shape)
        # for line in decoded:
        #     print(index2seq(line))

    def on_epoch_end(self, epoch, logs={}):
        wer = calc_wer(self.test_func, self.validation_gen)
        print("Average validation WER: ", wer[1], ".\n")
        self.values.append([logs.get('loss'), logs.get('val_loss'), wer[1]])

        if ((epoch+1) % self.checkpoint) == 0:
            if self.path_to_save:
                model_to_save = tf.keras.Model(self.model.inputs, self.model.outputs)
                model_to_save.save(self.path_to_save)
            self.save_log()

            predictions = []
            for idx in range(len(self.test_gen)):
                input_data, _ = self.test_gen.__getitem__(idx)
                x_data = input_data.get('input_layer')
                input_length = input_data.get('input_length')
                decoded = beam_decode(self.test_func, x_data, input_length)
                for line in decoded:
                    # print(line)
                    predictions.append(index2seq(line))
            submission = pd.DataFrame({'Predicted': predictions})
            submission.index.name = 'Id'
            submission.to_csv(self.submission_path, sep=',', index=True)
            del submission, predictions
            print("Predictions generated after 5 iterations!")

    def on_train_end(self, logs={}):
        # try:
        #     test_wer = calc_wer(self.test_func, self.test_gen)
        #     print ("\n - Training ended, test wer: ", test_wer[1], " -")
        # except(Exception, StandardError) as e :
        #     template = "An exception of type {0} occurred. Arguments:\n{1!r}"
        #     msgs = template.format(type(e).__name__, e.args)
        #     print(msgs)
        # print("\nPrediction samples:\n")    
        # prediction = predict_on_batch(self.validation_gen, self.test_func, 6)
        predictions = []
        for idx in range(len(self.test_gen)):
            input_data, _ = self.test_gen.__getitem__(idx)
            x_data = input_data.get('input_layer')
            input_length = input_data.get('input_length')
            decoded = beam_decode(self.test_func, x_data, input_length)
            for line in decoded:
                # print(line)
                predictions.append(index2seq(line))
        submission = pd.DataFrame({'Predicted': predictions})
        submission.index.name = 'Id'
        submission.to_csv(self.submission_path, sep=',', index=True)
        print("Predictions generated!")

    def save_log(self):
        stats = pd.DataFrame(data=self.values, columns=['loss', 'val_loss', 'wer'])
        stats.to_csv(self.log_file_path + "_" + self.timestamp)
        print ("Log file saved: ", self.log_file_path + "_" + self.timestamp)

def wers(originals, results):
    # input: two lists of sequences
    # originals: true label sequences
    # results: predicted label sequences
    count = len(originals)
    try:
        assert count > 0
    except:
        print(originals)
        raise("ERROR assert count > 0 - looks like data is missing")
    rates = []
    mean = 0.
    assert count == len(results)
    for i in range(count):
        rate = Levenshtein.distance(originals[i], results[i])
        mean = mean + rate
        rates.append(rate)
    return rates, mean/float(count)


def index2seq(label_seq):
    PHONEME = phoneme_list.PHONEME_MAP + ['']
    return "".join(map(PHONEME.__getitem__, label_seq))


def calc_wer(test_func, data_gen):
    """
    Calculate WER on all data from data_gen
    :param test_func: Keras function that takes preprocessed audio input and outputs network predictions
    :param data_gen: DataGenerator to produce input data
    :return: array containing [list of WERs from each batch, average WER for all batches]
    """
    out_true = []
    out_pred = []
    for batch in range(len(data_gen)):
        input_data, _ = data_gen.__getitem__(batch)
        x_data = input_data.get("input_layer")
        input_length = input_data.get('input_length')
        y_data = input_data.get("labels")

        for i in y_data:
            out_true.append(index2seq(i))

        decoded = beam_decode(test_func, x_data, input_length)
        # decoded: (predictions, probabilities)
        # predictions: (batch_size, top_k, sequence_len)
        for i in decoded:
            out_pred.append(index2seq(i))

    out = wers(out_true, out_pred)
    # out: (individual wer, mean wer) 

    return out    


def beam_decode(test_func, x_data, input_length):
    y_pred = test_func([x_data])[0]
    decoded = tf.keras.backend.ctc_decode(y_pred, input_length, greedy=False, beam_width=100, top_paths=1)[0][0]
    return K.get_value(decoded)


def train():
    num_epochs = configs.NUM_EPOCHS
    learning_rate = configs.LEARNING_RATE
    log_file = configs.LOG_FILE
    model_type = 'deep_lstm'
    units = configs.NUM_RNN_UNITS
    n_layers = configs.NUM_LAYERS
    sumbission = 'submission.csv'
    model_save = 'models/model_every_ckpt'
    checkpoint = 5
    model_load = False
    reduce_lr = True

    Train_Inputs = np.load(f'wsj0_train.npy', encoding='latin1')
    # Train_Inputs = Train_Inputs[:130]
    Valid_Inputs = np.load(f'wsj0_dev.npy', encoding='latin1')
    # Valid_Inputs = Valid_Inputs[:130]
    Test_Inputs = np.load(f'transformed_test_data.npy', encoding='latin1')
    # Test_Inputs = Test_Inputs[:130]
    Train_Labels = np.load(f'wsj0_train_merged_labels.npy')
    # Train_Labels = Train_Labels[:130]
    Valid_Labels = np.load(f'wsj0_dev_merged_labels.npy')
    # Valid_Labels = Valid_Labels[:130]

    training_generator = DataGenerator(Train_Inputs, Train_Labels)
    validation_generator = DataGenerator(Valid_Inputs, Valid_Labels, shuffle=False)
    test_generator = DataGenerator(Test_Inputs, [], shuffle=False, train=False)

    optimizer = tf.keras.optimizers.Adam(lr=learning_rate, epsilon=1e-8, clipnorm=2.0) # , clipnorm=2.0
    loss = {'ctc': lambda y_true, y_pred: y_pred} # dummy function to compile model

    num_batch = training_generator.__len__()

    loss_callback_params = {'validation_gen':validation_generator,
                            'test_gen': test_generator,
                            'checkpoint': checkpoint,
                            'path_to_save': model_save,
                            'log_file_path':'log',
                            'submission_path':sumbission}

    model_train_params = {'generator':training_generator,
                          'epochs': num_epochs,
                          'validation_data': validation_generator,
                          'verbose':2}

    if False:
        with tf.device('/cpu:0'):
            custom_objects = {'clipped_relu': modules.clipped_relu,
                                '<lambda>': lambda y_true, y_pred: y_pred,
                                'ctc_lambda_func':modules.ctc_lambda_func}
            net = tf.keras.models.load_model("models/model_every_ckpt_best", custom_objects=custom_objects)
            print("Loading previous model.")

    else:
        with tf.device('/cpu:0'):
            net = modules.model(model_type=model_type, units=units, input_dim=configs.FRAME_SIZE, output_dim=configs.NUM_CLASSES,
                                    dropout=configs.DROPOUT_PROB, cudnn=True, n_layers=configs.NUM_LAYERS)

    if reduce_lr:
        reduce_lr_cb = tf.keras.callbacks.ReduceLROnPlateau(factor=0.5, patience=1, verbose=1, min_delta=1, min_lr=1e-8)
        callbacks = [reduce_lr_cb]
    else:
        callbacks = []

    early_stop = tf.keras.callbacks.EarlyStopping(min_delta=0.001, patience=3, verbose=1, mode='auto')
    
    callbacks.append(early_stop)

    save_best = model_save + str("_best")
    mcp_cb = tf.keras.callbacks.ModelCheckpoint(save_best, verbose=1, save_best_only=True, period=1)
    callbacks.append(mcp_cb)
    net.compile(loss=loss, optimizer=optimizer)
    net.summary()

    input_data = net.get_layer('input_layer').input
    y_pred = net.get_layer('classifier').output
    test_func = K.function([input_data], [y_pred])
    loss_cb = LossCallback(test_func=test_func, model=net, **loss_callback_params)
    callbacks.append(loss_cb)
    net.fit_generator(callbacks=callbacks, **model_train_params)
    net.save(model_save)


train()

